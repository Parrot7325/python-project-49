### Hexlet tests and linter status:
[![Actions Status](https://github.com/Parrot7325/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Parrot7325/python-project-49/actions)
Аскинема: https://asciinema.org/a/ZUj9asjkDqex5EBUingzSuZHh
Аскинема к 7-ому шагу: https://asciinema.org/a/J7VlV3VgKVZKWDG8HsxpRpAct
Аскинема к 8-ому шагу: https://asciinema.org/a/EQUsyPa3OxbCnhtaEV34X1wtE
Аскинема к 9-ому шагу: https://asciinema.org/a/YQYZ7P7Er7mQDZbwm9yLZz6DW
