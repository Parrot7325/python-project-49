# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Первый учебный проект в курсе Хекслета. Набор мини-игр.',
    'long_description': '### Code Climate Maintainability Badge\n[![Maintainability](https://api.codeclimate.com/v1/badges/fdd618eadf00e7120361/maintainability)](https://codeclimate.com/github/Parrot7325/python-project-49/maintainability)\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Parrot7325/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Parrot7325/python-project-49/actions)\n\nДля быстрой установки выполните\n```\npython3 -m pip install --user dist/*.whl\n```\n\nДля установки с нуля (потребуется poetry) выполните\n```\nmake installation\n```\n\nДля запуска игры на четность/нечетность выполните\n```\nbrain-even\n```\n\nДля запуска игры на нахождение наименьшего общего делителя выполните\n```\nbrain-gcd\n```\n\nДля запуска игры на нахождение пропущенного элемента прогрессии выполните\n```\nbrain-progression\n```\n\nДля запуска игры на определение простого числа выполните\n```\nbrain-prime\n```\n\nДемонстрации:\n\n\nЗапуск brain-even: https://asciinema.org/a/ZUj9asjkDqex5EBUingzSuZHh\n\nЗапуск brain-gcd https://asciinema.org/a/J7VlV3VgKVZKWDG8HsxpRpAct\n\nЗапуск brain-progression: https://asciinema.org/a/EQUsyPa3OxbCnhtaEV34X1wtE\n\nЗапуск brain-prime: https://asciinema.org/a/YQYZ7P7Er7mQDZbwm9yLZz6DW\n',
    'author': 'Parrot7325',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Parrot7325/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
