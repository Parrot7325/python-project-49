# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts', 'brain_games.scripts.games']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.games.brain_calc:main',
                     'brain-even = brain_games.scripts.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.games.brain_gcd:main',
                     'brain-prime = brain_games.scripts.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Первый учебный проект в курсе Хекслета. Набор мини-игр.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Parrot7325/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Parrot7325/python-project-49/actions)\nАскинема: https://asciinema.org/a/ZUj9asjkDqex5EBUingzSuZHh\nАскинема к 7-ому шагу: https://asciinema.org/a/J7VlV3VgKVZKWDG8HsxpRpAct\nАскинема к 8-ому шагу: https://asciinema.org/a/EQUsyPa3OxbCnhtaEV34X1wtE\nАскинема к 9-ому шагу: https://asciinema.org/a/YQYZ7P7Er7mQDZbwm9yLZz6DW\n',
    'author': 'Parrot7325',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Parrot7325/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
